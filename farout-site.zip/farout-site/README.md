# Farout

A daily game: 7 everyday prompts, and the rarer your answer is across the internet, the farther your ship flies.

## How the scoring works
For every answer, the server asks Claude (with Claude's built-in **web search** tool) how often people online give that
same answer to that kind of prompt. That gives a "how common is this" estimate. As more players join each day, the
server blends in what **your real players typed** (identical answers count against you). Results are cached, so the same
answer to the same prompt always scores the same.

If the AI/web lookup is unavailable (no key, error, or the daily cap is hit), the game still works with a simple
built-in estimate, so it never breaks.

## Run it on your computer
1. Install Node.js 20 or newer (nodejs.org).
2. In this folder, run: `npm install`
3. Copy `.env.example` to `.env` and paste your Anthropic API key (console.anthropic.com).
   Then start with: `node --env-file=.env server.js`
4. Open http://localhost:3000

Without a key it still runs, just with the simple built-in scoring.

## Put it on the internet (Render, the easiest)
1. Create a free GitHub account and upload this folder as a new repository (do NOT upload `.env`).
2. On render.com: **New > Web Service**, connect the repo.
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
3. Add environment variables: `ANTHROPIC_API_KEY` (your key).
4. Keep players' answers between restarts: add a **Disk** (Render paid plan), mount it at `/var/data`, and set
   `DB_PATH=/var/data/farout.db`. Without a disk the database resets when the server restarts or redeploys.
5. Deploy. Render gives you a public URL; you can attach your own domain in Settings > Custom Domains.

Other hosts work too: Railway, Fly.io (use a volume for `DB_PATH`) or any host that can run Node or the included
`Dockerfile`.

## Before you open it to the public
- **Turn on web search** for your organization in the Anthropic Console (an admin setting), or the AI scoring will
  fall back to the simple estimate.
- **Set a spend limit** in the Anthropic Console. Each scored answer costs a small amount of model usage plus a
  per-search fee, and a player makes 7 a day. Check current prices at docs.claude.com.
- `DAILY_AI_CAP` (default 3000) stops AI scoring for the day once that many answers have been scored, so a surprise
  traffic spike can't run up a huge bill. Raise it as your audience grows.
- `CLAUDE_MODEL` lets you pick a cheaper or stronger Claude model (it must support the web search tool).
- The server limits each visitor to 20 requests a minute and one scored answer per player per prompt.
  Players are identified by a random ID stored in their browser, so a determined person can still clear it and replay.

## Changing things
- **Prompts:** edit the `PROMPTS` list near the top of `server.js` (7 are chosen per day, same for everyone).
- **Look and feel:** everything the player sees is in `public/index.html`.
- **New day:** prompts change at midnight UTC.

## Files
- `server.js` the backend (prompts, scoring, database)
- `public/index.html` the game
- `package.json`, `Dockerfile`, `.env.example`, `.gitignore`
